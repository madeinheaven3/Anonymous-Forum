const express = require("express");
const bodyParser = require("body-parser");
const { v4: uuidv4 } = require("uuid");
const app = express();

let posts = [];

// 👉 Admin-ID (z. B. generiert einmal oder per Cookie später)
const ADMIN_ID = "superadmin-123";

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

// ⛩ Captcha-Funktion
function generateCaptcha() {
  const a = Math.floor(Math.random() * 5 + 1);
  const b = Math.floor(Math.random() * 5 + 1);
  return { a, b, result: a + b };
}

let captchaCache = generateCaptcha();

// ▶ STARTSEITE mit Captcha
app.get("/", (req, res) => {
  const { a, b, result } = captchaCache;
  res.send(`
    <!DOCTYPE html><html><head>
    <link rel="stylesheet" href="/style.css">
    <title>Anonymous Forum</title></head><body>
    <h1>Anonymous Forum</h1>
    <p>Enter your username (max 12 characters) and solve the math task:</p>
    <form method="POST" action="/forum">
      <input type="text" name="username" maxlength="12" placeholder="Username" required><br><br>
      <label>What is <b>${a} + ${b}</b>?</label><br>
      <input type="text" name="captchaInput" placeholder="Just the number" required><br>
      <input type="hidden" name="captchaExpected" value="${result}">
      <input type="hidden" name="userId" value="${uuidv4()}">
      <br><button>Enter Forum</button>
    </form>
    </body></html>
  `);
});

// 🧠 Login-Handling
app.post("/forum", (req, res) => {
  const username = req.body.username?.substring(0, 12).replace(/</g, "&lt;");
  const captchaInput = parseInt(req.body.captchaInput);
  const captchaExpected = parseInt(req.body.captchaExpected);
  const userId = req.body.userId;

  if (captchaInput !== captchaExpected) return res.redirect("/");

  renderForum(res, username, userId);
});

// 📝 Beitrag posten
app.post("/post", (req, res) => {
  const text = req.body.text?.trim().replace(/</g, "&lt;");
  const username = req.body.username?.substring(0, 12).replace(/</g, "&lt;");
  const replyTo = req.body.replyTo?.trim();
  const userId = req.body.userId;
  const timestamp = new Date().toLocaleString("en-GB");

  if (text && username && userId) {
    posts.unshift({
      id: uuidv4(),
      username,
      text,
      timestamp,
      replyTo,
      authorId: userId
    });
  }

  renderForum(res, username, userId);
});

// ❌ Beitrag löschen
app.post("/delete", (req, res) => {
  const id = req.body.id;
  const userId = req.body.userId;

  const post = posts.find(p => p.id === id);
  if (!post) return res.redirect("/");

  // Nur Admin oder Eigentümer darf löschen
  if (post.authorId === userId || userId === ADMIN_ID) {
    posts = posts.filter(p => p.id !== id);
  }

  renderForum(res, post.username, userId);
});

// 🔁 Forum rendern
function renderForum(res, username, userId) {
  let html = `<!DOCTYPE html><html><head>
  <link rel="stylesheet" href="/style.css">
  <title>Forum – ${username}</title></head><body>
  <h2>Welcome, ${username}</h2>
  <form method="POST" action="/post">
    <input type="hidden" name="username" value="${username}">
    <input type="hidden" name="userId" value="${userId}">
    <textarea name="text" rows="4" placeholder="Your message..."></textarea><br>
    <button>Post</button>
  </form><hr>`;

  posts.forEach(p => {
    html += `
    <div class="post">
      <div class="post-header"><b>${p.username}</b> <span class="timestamp">[${p.timestamp}]</span></div>
      <div class="post-text">${p.text}</div>
      ${p.replyTo ? `<div class="reply-to">↳ In reply to: <i>${p.replyTo}</i></div>` : ""}
      ${(p.authorId === userId || userId === ADMIN_ID) ? `
      <form method="POST" action="/delete" style="display:inline;">
        <input type="hidden" name="id" value="${p.id}">
        <input type="hidden" name="userId" value="${userId}">
        <button class="delete-button">Delete</button>
      </form>` : ""}
      <form method="POST" action="/post" class="reply-form">
        <input type="hidden" name="username" value="${username}">
        <input type="hidden" name="userId" value="${userId}">
        <input type="hidden" name="replyTo" value="${p.username}">
        <input type="text" name="text" placeholder="Reply to ${p.username}" required>
        <button>Reply</button>
      </form>
    </div>`;
  });

  html += `</body></html>`;
  res.send(html);
}

app.listen(3000, () => console.log("Forum is running"));
